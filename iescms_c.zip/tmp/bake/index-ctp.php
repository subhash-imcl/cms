<?php
/**
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @since         0.1.0
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */
use Cake\Utility\Inflector;

$fields = collection($fields)
    ->filter(function($field) use ($schema) {
        return !in_array($schema->columnType($field), ['binary', 'text']);
    });

if (isset($modelObject) && $modelObject->behaviors()->has('Tree')) {
    $fields = $fields->reject(function ($field) {
        return $field === 'lft' || $field === 'rght';
    });
}

if (!empty($indexColumns)) {
    $fields = $fields->take($indexColumns);
}

?>

<div class="<?= $pluralVar ?> row">
    <div class="col-xs-12">
        <div class="box box-primary">
            <div class="box-header">
                <h3 class="leftHeader"><CakePHPBakeOpenTag= __('<?= $pluralHumanName ?>') CakePHPBakeCloseTag></h3>
                <div class="box-tools pull-right">
                    <CakePHPBakeOpenTag= $this->Html->link(__('New <?= $singularHumanName ?>'), ['action' => 'add'],['class'=>'btn btn-md btn-info btn-flat']) CakePHPBakeCloseTag>
                </div>
            </div>
            <div class="box-body">    
                <table class="table table-bordered">
                <thead>
                    <tr>
    <?php foreach ($fields as $field): ?>
    <?php
            if($field=='id'){  
    ?>
        <th scope="col" style="width:3%;"><CakePHPBakeOpenTag= $this->Paginator->sort('<?= $field ?>',__('SNO')) CakePHPBakeCloseTag></th>
    <?php 
            }else{ 
    ?>
            <th scope="col"><CakePHPBakeOpenTag= $this->Paginator->sort('<?= $field ?>') CakePHPBakeCloseTag></th>
    <?php 
            } 
    ?>
    <?php endforeach; ?>
            <th scope="col" class="actions" style="width:12%"><CakePHPBakeOpenTag= __('Actions') CakePHPBakeCloseTag></th>
                    </tr>
                </thead>
                <tbody>
                    <CakePHPBakeOpenTagphp
               <?= '$pageParam = $this->Paginator->params();' ?>

               <?= '$sno = (($pageParam["page"]-1)*$pageParam["perPage"])+1;' ?>

                    CakePHPBakeCloseTag>
                    <CakePHPBakeOpenTagphp foreach ($<?= $pluralVar ?> as $<?= $singularVar ?>): CakePHPBakeCloseTag>
                    <tr>
        <?php        foreach ($fields as $field) {
                    $isKey = false;
                    if (!empty($associations['BelongsTo'])) {
                        foreach ($associations['BelongsTo'] as $alias => $details) {
                            if ($field === $details['foreignKey']) {
                                $isKey = true;
        ?>
                        <td><CakePHPBakeOpenTag= $<?= $singularVar ?>->has('<?= $details['property'] ?>') ? $this->Html->link($<?= $singularVar ?>-><?= $details['property'] ?>-><?= $details['displayField'] ?>, ['controller' => '<?= $details['controller'] ?>', 'action' => 'view', $<?= $singularVar ?>-><?= $details['property'] ?>-><?= $details['primaryKey'][0] ?>]) : '' CakePHPBakeCloseTag></td>
        <?php
                                break;
                            }
                        }
                    }
                    if ($isKey !== true) {
                        if (!in_array($schema->columnType($field), ['integer', 'biginteger', 'decimal', 'float'])) {
        ?>
                        <td><CakePHPBakeOpenTag= h($<?= $singularVar ?>-><?= $field ?>) CakePHPBakeCloseTag></td>
        <?php
                        } elseif($field == 'id') {
        ?>
                    <td class="text-center"><CakePHPBakeOpenTag= $this->Number->format(<?= '$sno' ?>) CakePHPBakeCloseTag></td>
        <?php
                        } elseif($field == 'status') {
        ?>
        <?php  $pk = '$' . $singularVar . '->' . $primaryKey[0]; ?>
                    <td class="text-center">
                        <CakePHPBakeOpenTagphp if ($<?= $singularVar ?>-><?= $field ?><?= '==' ?>'1'): CakePHPBakeCloseTag>
                        <CakePHPBakeOpenTag= $this->Html->link('', ['action' => 'statuschange', <?= $pk ?>],['class'=>'btn btn-success btn-sm fa fa-plus-circle','title'=>'Enabled']) CakePHPBakeCloseTag>
                        <CakePHPBakeOpenTagphp else: CakePHPBakeCloseTag>
                        <CakePHPBakeOpenTag= $this->Html->link('', ['action' => 'statuschange', <?= $pk ?>],['class'=>'btn btn-danger btn-sm fa fa-minus-circle','title'=>'Disabled']) CakePHPBakeCloseTag>
                        <CakePHPBakeOpenTagphp endif; CakePHPBakeCloseTag>
                    </td>
                    
        <?php                        
                        }else{
        ?>
                        <td><CakePHPBakeOpenTag= $this->Number->format($<?= $singularVar ?>-><?= $field ?>) CakePHPBakeCloseTag></td>
        <?php
                        }
                    }
                }

                $pk = '$' . $singularVar . '->' . $primaryKey[0];
        ?>
                        <td class="actions">
                            <div class="btn-group text-center">
                            <CakePHPBakeOpenTag= $this->Html->link('', ['action' => 'view', <?= $pk ?>],['class'=>'btn btn-default btn-sm fa fa-eye','title'=>'View']) CakePHPBakeCloseTag>
                            <CakePHPBakeOpenTag= $this->Html->link('', ['action' => 'edit', <?= $pk ?>],['class'=>'btn btn-default btn-sm fa fa-pencil','title'=>'Edit']) CakePHPBakeCloseTag>
                            <CakePHPBakeOpenTag= $this->Form->postLink('', ['action' => 'delete', <?= $pk ?>], ['confirm' => __('Are you sure you want to delete # {0}?', <?= $pk ?>),'title'=>'Delete','class'=>'btn btn-default btn-sm fa fa-trash']) CakePHPBakeCloseTag>
                            </div>
                        </td>
                    </tr>
                   <CakePHPBakeOpenTagphp <?= '$sno++'  ?> CakePHPBakeCloseTag>
                    <CakePHPBakeOpenTagphp endforeach; CakePHPBakeCloseTag>
                </tbody>
            </table>
            <div class="box-footer clearfix">
                <ul class="pagination pagination-sm no-margin pull-right">
                    <CakePHPBakeOpenTag= $this->Paginator->first('<< ' . __('first')) CakePHPBakeCloseTag>
                    <CakePHPBakeOpenTag= $this->Paginator->prev('< ' . __('previous')) CakePHPBakeCloseTag>
                    <CakePHPBakeOpenTag= $this->Paginator->numbers() CakePHPBakeCloseTag>
                    <CakePHPBakeOpenTag= $this->Paginator->next(__('next') . ' >') CakePHPBakeCloseTag>
                    <CakePHPBakeOpenTag= $this->Paginator->last(__('last') . ' >>') CakePHPBakeCloseTag>
                </ul>
                <p><CakePHPBakeOpenTag= $this->Paginator->counter(['format' => __('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')]) CakePHPBakeCloseTag></p>
            </div>
            </div>
        </div>
    </div>
</div>
