<?php

/**
 * Author : Subahsh kumar
 * Description : This helper utilized by only admin activity.
 * Licensed under The MIT License
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org) 
 */

namespace App\View\Helper;

use Cake\Core\Configure;
use Cake\View\Helper;

class AdminHelper extends AppHelper {

    public $helpers = ['Html', 'Url'];

    public function __construct(View $View, $settings = array()) {
        parent::__construct($View, $settings);
    }

    /**
     * The Menu Builder generates the menu links for a website navagation, including generating dropdowns
     * @param  array $loadMenu
     * @param  array $options
     * @return void
     */
    public function leftMenus($loadMenu = array(), $options = array()) {
        if (!$loadMenu) {
            return false;
        }
        if (!empty($options['dropdown'])) {
            $ulOptions = array();
            if (!empty($options['ul'])) {
                $ulOptions = $options['ul'];
            }
            if (empty($ulOptions['class'])) {
                $ulOptions['class'] = 'dropdown-menu';
            }
            echo $this->Html->tag('ul', null, $ulOptions);
        }
        if (empty($options['active'])) {
            $options['active'] = 'active';
        }
        foreach ($loadMenu as $menu) {
            $liOptions = array();
            // lets build the li class
            $liClass = array();
            if (!empty($options['class'])) {
                $liClass[] = $options['class'];
            }
            if (str_replace($this->request->base, '', $this->request->here) == $menu['url']) {
                $liClass[] = $options['active'];
            }
            $class = implode(' ', $liClass);
            if ($class) {
                $liOptions['class'] = $class;
            }
            echo $this->Html->tag('li', null, $liOptions);
            $linkOptions = array();
            if (!empty($menu['new_window'])) {
                $linkOptions['target'] = '_blank';
            }
            if (!empty($menu['children'])) {
                $linkOptions['data-target'] = '#';
                $linkOptions['data-toggle'] = 'dropdown';
                $linkOptions['class'] = 'dropdown-toggle';
            }
            echo $this->Html->link($menu['title'], $menu['url'], $linkOptions);
            if (!empty($menu['children'])) {
                if (empty($options['children'])) {
                    $options['children'] = array();
                }
                $options['children']['dropdown'] = true;
                $this->leftMenus($menu['children'], $options['children']);
            }
            echo '</li>';
        }
        if (!empty($options['dropdown'])) {
            echo '</ul>';
        }
    }

}
