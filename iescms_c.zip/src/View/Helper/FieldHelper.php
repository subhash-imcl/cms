<?php
/**
 * Author : Subahsh kumar
 * Description : Custom input fields Helper which extend the default input field
 * Licensed under The MIT License
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org) 
 */
namespace App\View\Helper;

use Cake\View\Helper\FormHelper;
use Cake\View\Helper;
use Cake\Routing\Router;
use Cake\Core\Configure;

/**
 * CakePHP Editor
 * @author kiwitech
 */
class FieldHelper extends Helper {

    use Helper\IdGeneratorTrait;

    // Take advantage of other helpers
    public $helpers = ['Html', 'Form'];
    // Check if the tiny_mce.js file has been added or not
    private $_tinyScript = false;
    private $_datePickerScript = false;
    
    /**
     * datePicker method to load field with datepicker
     */
    
    public function datepicker($fieldName,$options = [], $dateOptions = []){
        $options['templates'] = [
            'inputContainer' => '<div class="input-group date {{type}}{{required}}">{{content}}<span class="input-group-addon"><i class="glyphicon glyphicon-th"></i></span></div>',
            'inputContainerError' =>'<div class="input-group date {{type}}{{required}} error">{{content}}<span class="input-group-addon"><i class="glyphicon glyphicon-th"></i></span></div>'
            ];
        if (!$this->_datePickerScript) {
            // We don't want to add this every time, it's only needed once
            $this->_datePickerScript = true;
            $this->Html->css('/vendors/datepicker/css/bootstrap-datepicker.min', ['block' => true]);
            $this->Html->script('/vendors/datepicker/js/bootstrap-datepicker.min', ['block' => true]);
        }
        $defaultOptions = ['todayBtn'=>'linked','autoclose'=>true];
        if(!empty($dateOptions)){
            $defaultOptions = array_merge($defaultOptions,$dateOptions);
        }
        
        $json = $this->jsonOption($defaultOptions);
        
        $this->Html->scriptStart(['block' => true]);
        echo '$(".input-group.date").datepicker('.$json.');';
        $this->Html->scriptEnd();
        return $this->Form->input($fieldName, $options);
        
    }

    /**
     * textarea method for input field.
     *
     * @param string $fieldName Name of a field, like this "Modelname.fieldname"
     * @param array $options Array of HTML attributes.
     * @param array $tinyoptions Array of TinyMCE attributes for this textarea
     * @param string $preset
     * @return string An HTML textarea element with TinyMCE
     */
    public function textarea($fieldName, $options = [], $tinyoptions = []) {

        if (!empty($tinyoptions['type'])) {
            $customOptions = $this->preset($tinyoptions['type']);
            unset($tinyoptions['type']);
        } else {
            $customOptions = $this->preset('basic');
        }
        $editorOptions = array_merge($customOptions, $tinyoptions);
        $this->tinyMceScript($fieldName, $editorOptions);
        $defaultOptions = ['type' => 'textarea'];
        $options = array_merge($defaultOptions, $options);
        return $this->Form->input($fieldName, $options);
    }
    
    /**
     * tinyMceScript method the tiny_mce.js file and constructs the options
     *
     * @param string $fieldName Name of a field, like this "Modelname.fieldname"
     * @param array $tinyoptions Array of TinyMCE attributes for this textarea
     * @return string JavaScript code to initialise the TinyMCE area
     */
    public function tinyMceScript($fieldName, $tinyoptions = []) {
        if (!$this->_tinyScript) {
            // We don't want to add this every time, it's only needed once
            $this->_tinyScript = true;
            $this->Html->script('/vendors/tinymce/tinymce.min', ['block' => true]);
        }
        // Ties the options to the field
        
        $tinyoptions = ["selector"=> "#".$this->_domId($fieldName)]+$tinyoptions;
       
        $json = $this->jsonOption($tinyoptions);
        $this->Html->scriptStart(['block' => true]);
        echo 'tinyMCE.init(' . $json . ');';
        $this->Html->scriptEnd();
    }

    /**
     * Creates a preset for TinyOptions
     *
     * @param string $name
     * @return array
     */
    private function preset($type = null) {
        $tinyArray = [];
        switch ($type) {
            case "full":
                $tinyArray = [
                    'height' => '500',
                    'theme' => 'modern',
                    'plugins' => [
                        'advlist autolink lists link image charmap print preview hr anchor pagebreak',
                        'searchreplace wordcount visualblocks visualchars code fullscreen',
                        'insertdatetime media nonbreaking save table contextmenu directionality',
                        'emoticons template paste textcolor colorpicker textpattern imagetools codesample toc'
                    ],
                    'toolbar1' => 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
                    'toolbar2' => 'print preview media | forecolor backcolor emoticons | codesample',
                    'image_advtab' => true,
                    'templates' => [
                        ['title' => 'Test template 1', 'content' => 'Test 1'],
                        ['title' => 'Test template 2', 'content' => 'Test 2']
                    ],
                    'content_css' => [
                        '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
                        '//www.tinymce.com/css/codepen.min.css'
                    ]
                ];
                break;
            case 'classic':
                $tinyArray = [
                    'height' => '500',
                    'plugins' => [
                        "advlist autolink autosave link image lists charmap print preview hr anchor pagebreak spellchecker",
                        "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
                        "table contextmenu directionality emoticons template textcolor paste fullpage textcolor colorpicker textpattern"
                    ],
                    'toolbar1' => 'newdocument fullpage | bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect',
                    'toolbar2' => 'cut copy paste | searchreplace | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image media code | insertdatetime preview | forecolor backcolor',
                    'toolbar3' => 'table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | spellchecker | visualchars visualblocks nonbreaking template pagebreak restoredraft',
                    'menubar' => false,
                    'toolbar_items_size' => 'small',
                    'style_formats' => [
                        ['title' => 'Bold text', 'inline' => 'b'],
                        ['title' => 'Red text', 'inline' => 'span', 'styles' => ['color' => '#ff0000']],
                        ['title' => 'Red header', 'block' => 'h1', 'styles' => ['color' => '#ff0000']],
                        ['title' => 'Example 1', 'inline' => 'span', 'classes' => 'example1'],
                        ['title' => 'Example 2', 'inline' => 'span', 'classes' => 'example2'],
                        ['title' => 'Table styles'],
                        ['title' => 'Table row 1', 'selector' => 'tr', 'classes' => 'tablerow1']
                    ],
                    'templates' => [
                        ['title' => 'Test template 1', 'content' => 'Test 1'],
                        ['title' => 'Test template 2', 'content' => 'Test 2']
                    ],
                    'content_css' => [
                        '//fast.fonts.net/cssapi/e6dc9b99-64fe-4292-ad98-6974f93cd2a2.css',
                        '//www.tinymce.com/css/codepen.min.css'
                    ]
                ];
                break;
            case 'basic':
            default:
                $tinyArray = [
                    'height' => '500',
                    'menubar' => false,
                    //'setup' => "function(ed) {ed.on('change', function(e) {var content = ed.getContent().replace(/(<([^>]+)>)/ig,\"\");var error = $('<div class=\"errorMsg\"><span class=\"error\">This field is required.</span></div>');if(content.length > 0){ $(container).removeClass('invalid').closest('div').find('div.errorMsg').remove();$(container).html(ed.getContent());tinymce.triggerSave();}else{ tinymce.triggerSave();$(container).removeClass('invalid').closest('div').find('div.errorMsg').remove();$(container).empty();$(container).addClass('invalid');error.insertAfter($(container));}});}",
                    'plugins' => [
                        'advlist autolink lists link image charmap print preview anchor',
                        'searchreplace visualblocks code fullscreen',
                        'insertdatetime media table contextmenu paste code'
                    ],
                    'toolbar' => 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
                    'content_css' => [
                        Router::url('/',true).'vendors/tinymce/tinymce.css'
                    ]
                ];
                break;
        }
        return $tinyArray;
    }
    
    /**
     * jsonOption convert option in json;
     * 
     * @param array $option input vedor options
     * @return json convert array into json
     * 
     */
    private function jsonOption($option){
        $json = [];
        $value_arr = array();
        $replace_keys = array();
        foreach ($option as $key => &$value) {
            // Checks if the value starts with 'function ('
            if (!is_array($value) && strpos($value, 'function(') === 0) {
                $value_arr[] = $value;
                $value = '%' . $key . '%';
                $replace_keys[] = '"' . $value . '"';
            }
        }
        // Encode the array in json
        $json = json_encode($option);

        // Replace the functions
        $json = str_replace($replace_keys, $value_arr, $json);
        return $json;
    }

}