<?php

return [
    'adminMenu' => [
        ['title' => 'Dashboard', 'url' => [], 'class' => '', 'children' => []],
        ['title' => 'Pages', 'url' => [], 'class' => '', 'children' => [
            ['title' => 'All Pages', 'url' => ['controller' => 'Pages', 'action' => 'allPages'], 'class' => '', 'children' => []],
            ['title' => 'New Page', 'url' => ['controller' => 'Pages', 'action' => 'addPage'], 'class' => '', 'children' => []],
        ]],
        ['title' => 'Posts', 'url' => [], 'class' => '', 'children' => [
            ['title' => 'All Posts', 'url' => ['controller' => 'Pages', 'action' => 'allPosts'], 'class' => '', 'children' => []],
            ['title' => 'New Post', 'url' => ['controller' => 'Pages', 'action' => 'addPost'], 'class' => '', 'children' => []],
        ]],
        ['title' => 'Users', 'url' => [], 'class' => '', 'children' => [
            ['title' => 'All Users', 'url' => ['controller' => 'Users', 'action' => 'allUser'], 'class' => '', 'children' => []],
            ['title' => 'New User', 'url' => ['controller' => 'Users', 'action' => 'addUser'], 'class' => '', 'children' => []],
        ]],
        ['title' => 'Menus', 'url' => ['controller' => 'Menus', 'action' => 'index'], 'class' => '', 'children' => []],
        ['title' => 'Social', 'url' => ['controller' => 'Settings', 'action' => 'social'], 'class' => '', 'children' => []],
        ['title' => 'Settings', 'url' => ['controller' => 'Settings', 'action' => 'social'], 'class' => '', 'children' => [
            ['title' => 'Configuration', 'url' => ['controller' => 'Settings', 'action' => 'index', 'default-config'], 'class' => '', 'children' => []],
            ['title' => 'All Settings', 'url' => ['controller' => 'Settings', 'action' => 'allSettings'], 'class' => '', 'children' => []],
            ['title' => 'New Setting', 'url' => ['controller' => 'Settings', 'action' => 'New Settings'], 'class' => '', 'children' => []],
        ]],
    ]
];
